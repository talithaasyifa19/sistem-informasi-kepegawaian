<?php $__env->startSection('konten'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
  <?php if(count($errors) > 0): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($error); ?> <br/>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
  </div>
  </div>
  <?php if($message = Session::get('alert-success')): ?>
      <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong><?php echo e($message); ?></strong>
      </div>
    <?php endif; ?>
<div class="row">
<div class="col-md-3">
<div class="card shadow mb-4 align-middle">
    <div class="card-body">
    <img src="../../foto/<?php echo e($pegawai->foto); ?>" width="180px" />
    </div>
    </div>
    </div>

    <div class="col-md-3">
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary text-center"><?php echo e($pegawai->nama); ?></h6>
  </div>
    <div class="card-body">
<i class="fa fa-address-card"></i> <?php echo e($pegawai->nip); ?> <hr>
<i class="fa fa-phone"></i> <?php echo e($pegawai->no_telp); ?><hr>
<i class="fa fa-envelope"></i> <?php echo e($pegawai->sts_pegawai); ?>

    </div>
    </div>
    </div>

    <div class="col-md-6">
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary text-center">Riwayat</h6>
  </div>
    <div class="card-body">
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalDiklat">Diklat</button>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#ModalGapok">Gapok</button>
<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#ModalHukuman">Hukuman</button><hr>
<!-- row 2 -->
<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#ModalJabatan">Jabatan</button>
  <button type="button" class="btn btn-info" data-toggle="modal" data-target="#ModalJabatanfungsional">Jabatan Fungsional</button>
  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#ModalJabatanfungsionaltambahan">Jabatan Tambahan</button>
    </div>
    </div>
    </div>

<!-- row -->
    </div>


    <div class="row">
  <div class="col-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">Profile</a>
      <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Suami Istri</a>
      <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">Anak</a>
      <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">Ortu</a>
    
    </div>
  </div>

  
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
      <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
  
      <div class="col-md-10">
     <div class="card shadow mb-4 pl-5 pt-5 pr-5">

     <!-- row 1 -->
     <div class="row">
     <div class="col-md-4"> NIP
     </div>
     <div class="col-md-8"> : <?php echo e($pegawai->nip); ?>

     </div>
     </div>
     <hr>

     <!-- row 2 -->

     <div class="row">
     <div class="col-md-4"> Nama
     </div>
     <div class="col-md-8"> : <?php echo e($pegawai->nama); ?>

     </div>
     </div>
     <hr>

          <!-- row 3 -->

      <div class="row">
     <div class="col-md-4"> Tempat, Tanggal Lahir
     </div>
     <div class="col-md-8"> : <?php echo e($pegawai->t_lahir); ?>, <?php echo e($pegawai->tgl_lahir); ?>

     </div>
     </div>
     <hr>

          <!-- row 4 -->

          <div class="row">
     <div class="col-md-4"> Agama
     </div>
     <div class="col-md-8"> : <?php echo e($pegawai->agama->agama); ?>

     </div>
     </div>
     <hr>

          <!-- row 5 -->

          <div class="row">
     <div class="col-md-4"> Jenis Kelamin
     </div>
     <div class="col-md-8"> : <?php if($pegawai->jns_kelamin == 'L'): ?> Laki-laki <?php else: ?> Perempuan <?php endif; ?>
     </div>
     </div>
     <hr>

          <!-- row 6 -->

          <div class="row">
     <div class="col-md-4"> Hobi
     </div>
     <div class="col-md-8"> : <?php echo e($pegawai->hobi); ?>

     </div>
     </div>
     <hr>

          <!-- row 7 -->

          <div class="row">
     <div class="col-md-4"> Status Pernikahan
     </div>
     <div class="col-md-8"> : <?php echo e($pegawai->sts_marital); ?>

     </div>
     </div>
     <hr>

          <!-- row 8 -->

          <div class="row">
     <div class="col-md-4"> Status Kepegawaian
     </div>
     <div class="col-md-8"> : <?php echo e($pegawai->sts_pegawai); ?>

     </div>
     </div>
     <hr>

          <!-- row 9 -->

          <div class="row">
     <div class="col-md-4"> Pendidikan
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($pp->pendidikan); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 10 -->

          <div class="row">
     <div class="col-md-4"> No. Telp
     </div>
     <div class="col-md-8"> : <?php echo e($pegawai->no_telp); ?>

     </div>
     </div>
     <hr>

          

     <!-- card shadow -->
     </div>
     <!-- col -->
     </div>

      </div>
      <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
      
      <div class="col-md-10">
     <div class="card shadow mb-4 p-3">
     <?php if($pegawai->suamiistri->count() !== 0): ?>
     <!-- row 2 -->

     <div class="row">
     <div class="col-md-4"> Nama
     </div>
     <div class="col-md-8"> :  <?php $__currentLoopData = $pegawai->suamiistri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($psi->nama_istri_suami); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 3 -->

      <div class="row">
     <div class="col-md-4"> Tempat Lahir
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->suamiistri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($psi->t_lahir); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

     <div class="row">
     <div class="col-md-4"> Tanggal Lahir
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->suamiistri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($psi->tgl_lahir); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 4 -->

          <div class="row">
     <div class="col-md-4"> Jenis Kelamin
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->suamiistri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php if($psi->jns_kelamin == 'L'): ?> Laki-laki <?php else: ?> Perempuan <?php endif; ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 5 -->

          <div class="row">
     <div class="col-md-4"> Pendidikan
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->suamiistri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $__currentLoopData = $psi->pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendidikan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($pendidikan->pendidikan); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 6 -->

          <div class="row">
     <div class="col-md-4"> Status Tunjangan
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->suamiistri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($psi->sts_tunjangan); ?><span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 7 -->

          <div class="row">
     <div class="col-md-4"> Tanggal Pernikahan
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->suamiistri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($psi->tgl_menikah); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 8 -->

          <div class="row">
     <div class="col-md-4"> Keterangan
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->suamiistri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($psi->ket); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>
     <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalSuami"><i class="fa fa-plus"></i></button>
     <?php else: ?>
     Belum ada data Suami istri . <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalSuami"><i class="fa fa-plus"></i></button>

     <?php endif; ?>
 
     <!-- card shadow -->
     </div>
     <!-- col -->
     </div>

      </div>
      <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
<div class="col-md-10">
<div class="card shadow mb-4 p-3">
<?php if($pegawai->anak->count() !== 0): ?>
       <!-- row 2 -->
  
       <div class="row">
       <div class="col-md-4"> Nama
       </div>
       <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($anak->nama_anak); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       </div>
       <hr>
  
            <!-- row 3 -->
  
        <div class="row">
       <div class="col-md-4"> Tempat, Tanggal Lahir
       </div>
       <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($anak->t_lahir); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> , <?php $__currentLoopData = $pegawai->anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($anak->tgl_lair); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       </div>
       <hr>
  
            <!-- row 4 -->
  
            <div class="row">
       <div class="col-md-4"> Jenis Kelamin
       </div>
       <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($anak->jns_kelamin); ?> <span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       </div>
       <hr>
  
            <!-- row 5 -->
  
            <div class="row">
       <div class="col-md-4"> Pendidikan
       </div>
       <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $__currentLoopData = $anak->pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($pdd->pendidikan); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       </div>
       <hr>
  
            <!-- row 6 -->
  
            <div class="row">
       <div class="col-md-4"> Status Tunjangan
       </div>
       <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($anak->sts_tunjangan); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       </div>
       <hr>
  
            <!-- row 7 -->
  
            <div class="row">
       <div class="col-md-4"> Status Pernikahan
       </div>
       <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($anak->sts_menikah); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       </div>
       <hr>
  
            <!-- row 8 -->
  
            <div class="row">
       <div class="col-md-4"> Keterangan
       </div>
       <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($anak->ket); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       </div>
       <hr>
       <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalAnak"><i class="fa fa-plus"></i></button>
  <?php else: ?>
  Belum ada data anak. <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalAnak"><i class="fa fa-plus"></i></button>
  
  <?php endif; ?>
   
       <!-- card shadow -->
       </div>
       <!-- col -->
       </div>
        </div>


      <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
      
      <div class="col-md-10">
     <div class="card shadow mb-4 p-3">
     <?php if($pegawai->orangtua->count() !== 0): ?>

     <!-- row 2 -->

     <div class="row">
     <div class="col-md-4"> Nama
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($org->nama_ortu); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 3 -->

      <div class="row">
     <div class="col-md-4"> Tempat, Tanggal Lahir
     </div>
     <div class="col-md-8"> :  <?php $__currentLoopData = $pegawai->orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($org->t_lahir); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>,  <?php $__currentLoopData = $pegawai->orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($org->tgl_lahir); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 4 -->

          <div class="row">
     <div class="col-md-4"> Status
     </div>
     <div class="col-md-8"> : <?php $__currentLoopData = $pegawai->orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($org->jns_kelamin); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 5 -->

          <div class="row">
     <div class="col-md-4"> Alamat
     </div>
     <div class="col-md-8"> :  <?php $__currentLoopData = $pegawai->orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($org->alamat); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 6 -->

          <div class="row">
     <div class="col-md-4"> Pekerjaan
     </div>
     <div class="col-md-8"> :  <?php $__currentLoopData = $pegawai->orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($org->pekerjaan); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>

          <!-- row 7 -->

          <div class="row">
     <div class="col-md-4"> Keterangan
     </div>
     <div class="col-md-8"> :  <?php $__currentLoopData = $pegawai->orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($org->ket); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
     <hr>
     <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalOrtu"><i class="fa fa-plus"></i></button>
<?php else: ?>
Belum ada data orangtua. <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalOrtu"><i class="fa fa-plus"></i></button>

<?php endif; ?>
     <!-- card shadow -->
     </div>
     <!-- col -->
     </div>

</div>
</div>
</div>
</div>
</div>


<!-- Modal Suami istri -->
<div class="modal fade" id="ModalSuami" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Suami Istri</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="/pegawai/suamiistri/tambah/proses" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-row">
        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
<div class="form-group col-md-4">
<label for="inputKarpeg">Nama</label>
<input type="text" name="nama" id="inputKarpeg" class="form-control" required>
</div>
<div class="form-group col-md-4">
  <label for="inputTtl">Tempat</label>
  <input type="text" name="t_lahir" class="form-control">
  </div>
  <div class="form-group col-md-4">
  <label for="inputTgl">Tgl Lahir</label>
  <input type="date" name="tgl_lahir" class="form-control">
  </div>
  <div class="form-group col-md-4">
  <label for="inputStatus">Jenis Kelamin</label>
  <select name="kelamin" id="inputUser" class="form-control" required>
  <option>---</option>

  <option value="L">Laki-laki</option>
  <option value="P">Perempuan</option>

  </select>
  </div>
  <div class="form-group col-md-4">
  <label for="inputStatus">Pendidikan</label>
  <select name="pendidikan" id="inputUser" class="form-control" required>
  <option>---</option>
<?php $__currentLoopData = $pendidikans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($pdds->kode_pdd); ?>"><?php echo e($pdds->pendidikan); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  </div>
<div class="form-group col-md-4">
  <label for="inputStatus">Tanggal Pernikahan</label>
<input type="date" name="tgl_menikah" class="form-control">
  </div>
  <div class="form-group col-md-6">
  <label for="inputStatus">Status Tunjangan</label>
  <select name="sts_tunjangan" id="inputUser" class="form-control" required>
  <option>---</option>
  <option value="Ya">Iya</option>
  <option value="Tidak">Tidak</option>
  </select>
  </div>
  <div class="form-group col-md-6">
  <label for="inputStatus">Keterangan</label>
  <input type="text" class="form-control" name="keterangan">
  </div>
</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Tambah</button></form>
      </div>
    </div>
  </div>
</div>
</div>
<!-- End Modal suami istri -->

<!-- Modal Anak -->
<div class="modal fade" id="ModalAnak" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Anak</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="/pegawai/anak/tambah/proses" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
        <div class="form-row">
<div class="form-group col-md-4">
<label for="inputKarpeg">Nama</label>
<input type="text" name="nama" id="inputKarpeg" class="form-control" required>
</div>
<div class="form-group col-md-4">
  <label for="inputTtl">Tempat</label>
  <input type="text" name="t_lahir" class="form-control">
  </div>
  <div class="form-group col-md-4">
  <label for="inputTgl">Tgl Lahir</label>
  <input type="date" name="tgl_lahir" class="form-control">
  </div>
  <div class="form-group col-md-4">
  <label for="inputStatus">Jenis Kelamin</label>
  <select name="kelamin" id="inputUser" class="form-control" required>
  <option>---</option>

  <option value="L">Laki-laki</option>
  <option value="P">Perempuan</option>

  </select>
  </div>
  <div class="form-group col-md-4">
  <label for="inputStatus">Pendidikan</label>
  <select name="pendidikan" id="inputUser" class="form-control" required>
  <option>---</option>
  <?php $__currentLoopData = $pendidikans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($pdds->kode_pdd); ?>"><?php echo e($pdds->pendidikan); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  </div>
<div class="form-group col-md-4">
  <label for="inputStatus">Status Pernikahan</label>
  <select name="sts_pernikahan" id="inputUser" class="form-control" required>
  <option>---</option>
  <option value="Menikah">Menikah</option>
  <option value="Belum menikah">Belum menikah</option>
  </select>
  </div>
  <div class="form-group col-md-6">
  <label for="inputStatus">Status Tunjangan</label>
  <select name="sts_tunjangan" id="inputUser" class="form-control" required>
  <option>---</option>
  <option value="Iya">Iya</option>
  <option value="Tidak">Tidak</option>
  </select>
  </div>
  <div class="form-group col-md-6">
  <label for="inputStatus">Keterangan</label>
  <input type="text" class="form-control" name="keterangan">
  </div>
</div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Tambah</button></form>
      </div>
    </div>
  </div>
</div>
<!-- End Modal Anak -->


<!-- Modal Ortu -->
<div class="modal fade" id="ModalOrtu" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Ortu</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="/pegawai/orangtua/tambah/proses" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
        <div class="form-row">
<div class="form-group col-md-4">
<label for="inputKarpeg">Nama</label>
<input type="text" name="nama" id="inputKarpeg" class="form-control" required>
</div>
<div class="form-group col-md-4">
  <label for="inputTtl">Tempat</label>
  <input type="text" name="t_lahir" class="form-control">
  </div>
  <div class="form-group col-md-4">
  <label for="inputTgl">Tgl Lahir</label>
  <input type="date" name="tgl_lahir" class="form-control">
  </div>
  <div class="form-group col-md-6">
  <label for="inputStatus">Jenis Kelamin</label>
  <select name="kelamin" id="inputUser" class="form-control" required>
  <option>---</option>

  <option value="L">Laki-laki</option>
  <option value="P">Perempuan</option>

  </select>
  </div>
 
  <div class="form-group col-md-6">
  <label for="inputStatus">Alamat</label>
  <input type="text" class="form-control" name="alamat">
  </div>
</div>
<div class="form-row">
<div class="form-group col-md-6">
<label for="inputStatus">Pekerjaan</label>
  <input type="text" class="form-control" name="pekerjaan">
</div>
<div class="form-group col-md-6">
<label for="inputStatus">Keterangan</label>
  <input type="text" class="form-control" name="keterangan">
</div>
</div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Tambah</button></form>
      </div>
    </div>
  </div>
</div>
<!-- End Modal ortu -->

<!-- Modal diklat -->
<div class="modal fade" id="ModalDiklat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Diklat</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="pills-tambah-tab" data-toggle="pill" href="#pills-tambah" role="tab" aria-controls="pills-tambah" aria-selected="true">Tambah</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Hapus</a>
  </li>
</ul>
<div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
  <!-- Data home  diklat-->
  <div class="card p-3">
  <?php if($pegawai->riwayatdiklat->count() !== 0): ?>
  <div class="row">
  <div class="col-md-6">
  Nama Diklat
  </div>
  <div class="col-md-6">
  : <?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rd->nama_diklat); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
  <hr>

  <div class="row">
  <div class="col-md-6">
  Jenis Diklat
  </div>
  <div class="col-md-6">
  : <?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  <span class="badge badge-success"><?php echo e($rd->diklat->jenis_diklat); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
  <hr>

  <div class="row">
  <div class="col-md-6">
  Tanggal Mulai
  </div>
  <div class="col-md-6">
  : <?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-secondary"><?php echo e($rd->tgl_mulai); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
  <hr>

  <div class="row">
  <div class="col-md-6">
  Tanggal Selesai
  </div>
  <div class="col-md-6">
  : <?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-warning"><?php echo e($rd->tgl_selesai); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
  <hr>

  <div class="row">
  <div class="col-md-6">
  Nomor Sertifikat
  </div>
  <div class="col-md-6">
  : <?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-danger"><?php echo e($rd->no_sertifikat); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
  <hr>

  <div class="row">
  <div class="col-md-6">
  Tahun Sertifikat
  </div>
  <div class="col-md-6">
  : <?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-dark"><?php echo e($rd->thn_sertifikat); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
  <hr>

  <div class="row">
  <div class="col-md-6">
  Penyelenggara
  </div>
  <div class="col-md-6">
  : <?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-info"><?php echo e($rd->penyelenggara); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-6">
  Aksi
  </div>
  <div class="col-md-6">
  : <?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a class="btn btn-primary btn-sm" href="/pegawai/riwayatdiklat/editpage/<?php echo e($rd->id_diklat); ?>/<?php echo e($pegawai->id_peg); ?>">Edit</a>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
  <?php else: ?>
  Belum ada data riwayat diklat
  <?php endif; ?>
  </div>
  <!-- end data home diklat -->
  </div>
  <div class="tab-pane fade" id="pills-tambah" role="tabpanel" aria-labelledby="pills-tambah-tab">
    <!-- Start tambah data diklat -->
    <form action="/pegawai/diklat/tambah" method="POST">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
    <div class="form-row">
<div class="form-group col-md-6">
<label>Nama Diklat</label>
<input type="text" name="nama_diklat" class="form-control" required>
<!-- form group -->
</div>

    <div class="form-group col-md-6">
    <label>Jenis Diklat</label>
    <select name="jenis_diklat" class="form-control" required>
        <?php $__currentLoopData = $diklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dikl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($dikl->kode_diklat); ?>"><?php echo e($dikl->jenis_diklat); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <!-- form group -->
    </div>

    <!-- form row -->
</div> 


<div class="form-row">
        <div class="form-group col-md-6">
        <label>Tanggal Mulai</label>
        <input type="date" name="tgl_mulai" class="form-control" required>
        <!-- form group -->
        </div>

        <div class="form-group col-md-6">
                <label>Tanggal Selesai</label>
                <input type="date" name="tgl_selesai" class="form-control" required>
                <!-- form group -->
                </div>
    <!-- form row -->
</div> 

<div class="form-row">
        <div class="form-group col-md-6">
        <label>Nomor Sertifikat</label>
        <input type="text" name="nmr_sertifikat" class="form-control" required>
        <!-- form group -->
        </div>

        <div class="form-group col-md-6">
                <label>Tahun Sertifikat</label>
                <input type="number" name="thn_sertifikat" class="form-control" required>
                <!-- form group -->
                </div>
    <!-- form row -->
</div> 

<div class="form-row">
        <div class="form-group col-md-12">
        <label>Penyelenggara</label>
        <input type="text" name="penyelenggara" class="form-control" required>
        <!-- form group -->
        </div>
    <!-- form row -->
</div> 

<!-- button tambah -->
<div class="form-row">
<button type="sumbit" name="submit" class="btn btn-primary">Tambah</button>
</div>
<!-- button tambah end -->
</form>
    <!-- end tambah data diklat -->
  </div>
  <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
    <?php if($edit !== NULL): ?>
<!-- start hapus diklat -->
<?php $__currentLoopData = $pegawai->riwayatdiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/pegawai/diklat/hapus/<?php echo e($rd->id_diklat); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
<button type="submit" class="btn btn-danger btn-sm m-2">Hapus <?php echo e($rd->nama_diklat); ?></button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- end hapus diklat -->
<?php else: ?>
Belum ada data diklat
<?php endif; ?>
  </div>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- end modal diklat -->

<!-- start modal gapok -->
<div class="modal fade" id="ModalGapok" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Data Gapok</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
          <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Home</a>
          <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Tambah</a>
          <a class="nav-item nav-link" id="nav-hapus-tab" data-toggle="tab" href="#nav-hapus" role="tab" aria-controls="nav-hapus" aria-selected="false">Hapus</a>
        </div>
      </nav>
      <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
        <!-- Start home gapok -->
        <div class="card p-3">
        <?php if($pegawai->riwayatgapok->count() !== 0): ?>
        <div class="row">
<div class="col-md-5">
Nomor SK
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatgapok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rg->no_sk); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Tanggal SK
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatgapok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rg->tgl_sk); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Surat Keputusan Pejabat
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatgapok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rg->pejabat_sk); ?> </span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Terhitung Mulai Tanggal
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatgapok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rg->tmt); ?> </span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Keterangan
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatgapok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rg->ket); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Aksi
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatgapok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a class="btn btn-primary btn-sm" href="/pegawai/gapok/editpage/<?php echo e($rg->id_gapok); ?>/<?php echo e($pegawai->id_peg); ?>"> Edit </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>
<?php else: ?>
Belum ada data Gapok
<?php endif; ?>
        </div>
        <!-- End home gapok -->
        </div>
        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">  
        <div class="card p-3">
        <!-- card -->
        <form action="/pegawai/gapok/tambah" method="POST">
        <?php echo e(csrf_field()); ?>


        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
       
        <div class="form-row p-2">
        <div class="col-md-6">
        <label>No SK</label>
        <input type="text" name="no_sk" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Tanggal SK</label>
        <input type="date" name="tgl_sk" class="form-control">
        </div>
        <!-- form-row -->
        </div>

        <div class="form-row p-2">
        <div class="col-md-6">
        <label>Pejabat Pengesah</label>
        <input type="text" name="pejabat_sk" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Gaji Pokok</label>
        <select name="kode_gapok" class="form-control">
        <?php $__currentLoopData = $gapok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($gp->kode_gapok); ?>"><?php echo e($gp->gapok); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        <!-- form-row -->
        </div>

        <div class="form-row p-2">
        <div class="col-md-6">
        <label>Terhitung Mulai</label>
        <input type="date" name="tmt" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Naik Selanjutnya</label>
        <input type="date" name="naik_selanjutnya" class="form-control">
        </div>
        <!-- form-row -->
        </div>

        <div class="row">
        <div class="col-md-12">
        <label>Keterangan</label>
        <input type="text" name="ket" class="form-control">
        </div>
        </div>
        <div class="form-row m-2">
        <input type="submit" value="Tambah" class="btn btn-success">
        </div>
        </form>
        <!-- end card -->
        </div>

        </div>
      
        <div class="tab-pane fade" id="nav-hapus" role="tabpanel" aria-labelledby="nav-hapus-tab">
  <?php if($pegawai->riwayatgapok->count() !== 0): ?>
<!-- start hapus diklat -->
<?php $__currentLoopData = $pegawai->riwayatgapok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/pegawai/gapok/hapus/<?php echo e($rg->id_gapok); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
<button type="submit" class="btn btn-danger m-2">Hapus gapok dgn SK <?php echo e($rg->no_sk); ?></button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- end hapus diklat -->
<?php else: ?>
Belum ada gapok
<?php endif; ?>
  </div>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- end modal gapok -->


<!-- start modal hukuman -->
<div class="modal fade" id="ModalHukuman" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Data Hukuman</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <nav>
      <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <a class="nav-item nav-link active" id="nav-home-tab1" data-toggle="tab" href="#nav-home1" role="tab" aria-controls="nav-home1" aria-selected="true">Home</a>
        <a class="nav-item nav-link" id="nav-profile-tab1" data-toggle="tab" href="#nav-profile1" role="tab" aria-controls="nav-profile1" aria-selected="false">Tambah</a>
        <a class="nav-item nav-link" id="nav-hapus-tab1" data-toggle="tab" href="#nav-hapus1" role="tab" aria-controls="nav-hapus1" aria-selected="false">Hapus</a>
      </div>
    </nav>
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade show active" id="nav-home1" role="tabpanel" aria-labelledby="nav-home-tab1">
<!-- start home hukuman -->
<div class="card p-3">
<?php if($pegawai->riwayatindisipliner->count() !== 0): ?>
<div class="row">
<div class="col-md-5">
Hukuman
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatindisipliner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rid->hukuman); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
No SK
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatindisipliner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rid->no_sk); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Tanggal SK
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatindisipliner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rid->tgl_sk); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Pejabat Pengesah
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatindisipliner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rid->pejabat_sk); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Aksi
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatindisipliner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a class="btn btn-primary btn-sm" href="/pegawai/hukuman/editpage/<?php echo e($rid->id_hukuman); ?>/<?php echo e($pegawai->id_peg); ?>">Edit</a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php else: ?>
Data belum ada
<?php endif; ?>
</div>
<!-- end home hukuman -->
      </div>
      <div class="tab-pane fade" id="nav-profile1" role="tabpanel" aria-labelledby="nav-profile-tab1">

        <div class="card p-3">
        <!-- start tambah hukuman -->
        
        <form action="/pegawai/hukuman/tambah" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
        <div class="row">

        <div class="col-md-6">
        <label>Hukuman</label>
        <input type="text" name="hukuman" class="form-control">
        </div>

        <div class="col-md-6">
        <label>No. SK</label>
        <input type="text" name="no_sk" class="form-control">
        </div>

        </div>

        <div class="row">
        
        <div class="col-md-6">
        <label>Tanggal SK</label>
        <input type="date" name="tgl_sk" class="form-control">
        </div>

        <div class="col-md-6">
        <label>Pejabat Pengesah</label>
        <input type="text" name="pejabat_sk" class="form-control">
        </div>

        </div>

        <div class="row">
        <div class="col-md-12">
        <label>Keterangan</label>
        <input type="text" name="ket" class="form-control">
        </div>
        </div>
        <div class="row m-3">
        <input type="submit" value="Tambah" class="btn btn-primary">
        </div>
        </form>
        <!-- end tambah hukuman -->
        </div>
        </div>
      <div class="tab-pane fade" id="nav-hapus1" role="tabpanel" aria-labelledby="nav-hapus-tab1">
    <?php if($pegawai->riwayatindisipliner->count() !== 0): ?>
<!-- start hapus diklat -->
<?php $__currentLoopData = $pegawai->riwayatindisipliner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/pegawai/hukuman/hapus/<?php echo e($rid->id_hukuman); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">
<button type="submit" class="btn btn-danger btn-sm m-2">Hapus <?php echo e($rid->hukuman); ?></button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- end hapus diklat -->
<?php else: ?>
Belum ada data hukuman
<?php endif; ?>
  </div>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- end modal hukuman -->


<!-- start modal jabatan -->
<div class="modal fade" id="ModalJabatan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Data Jabatan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active" id="nav-home-tab2" data-toggle="tab" href="#nav-home2" role="tab" aria-controls="nav-home2" aria-selected="true">Home</a>
    <a class="nav-item nav-link" id="nav-profile-tab2" data-toggle="tab" href="#nav-profile2" role="tab" aria-controls="nav-profile2" aria-selected="false">Tambah</a>
    <a class="nav-item nav-link" id="nav-hapus-tab2" data-toggle="tab" href="#nav-hapus2" role="tab" aria-controls="nav-hapus2" aria-selected="false">Hapus</a>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-home2" role="tabpanel" aria-labelledby="nav-home-tab2">
  <!-- start home jabatan -->
  <div class="card p-3">
  <?php if($pegawai->riwayatjabatan->count() !== 0): ?>
<div class="row">
<div class="col-md-5">
Nama Jabatan
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbt->jabatanstruktural->nama_jabatan); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Level
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbt->jabatanstruktural->level); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Eselon
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbt->jabatanstruktural->eselon); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
No SK
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbt->no_sk); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Tanggal SK
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbt->tgl_sk); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Pejabat Pengesah
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rjbt->pejabat_sk); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Terhitung Mulai
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbt->tmt); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Keterangan Riwayat
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbt->ket); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Keterangan Jabatan
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rjbt->jabatanstruktural->ket); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<div class="row">
<div class="col-md-5">
Aksi
</div>
<div class="col-md-7">
: <?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a class="btn btn-primary btn-sm" href="/pegawai/jabatan/editpage/<?php echo e($rjbt->id_jabatan); ?>/<?php echo e($pegawai->id_peg); ?>">Edit</a>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><hr>

<?php else: ?>
Belum ada data
<?php endif; ?>

  </div>
  <!-- end home jabatan -->
  </div>
  <div class="tab-pane fade" id="nav-profile2" role="tabpanel" aria-labelledby="nav-profile-tab2">
 
        <div class="card p-3">
        <!-- card -->
        <form action="/pegawai/jabatan/tambah" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">

        <div class="row">
        <div class="col-md-6">
        <label >No. SK</label>
        <input type="text" name="no_sk" class="form-control">
        </div>
        <div class="col-md-6">
        <label >Tanggal SK</label>
        <input type="date" name="tgl_sk" class="form-control">
        </div>
        </div>

        <div class="row">
        <div class="col-md-6">
        <label >Pejabat Pengesah</label>
        <input type="text" name="pejabat_sk" class="form-control">
        </div>
        <div class="col-md-6">
        <label >Jabatan Struktural</label>
        <select name="kode_jbts" class="form-control">
        <?php $__currentLoopData = $jbts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($jb->kode_jbts); ?>"><?php echo e($jb->nama_jabatan); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        </div>

        <div class="row">
        <div class="col-md-6">
        <label>Terhitung Mulai</label>
        <input type="date" name="tmt" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Golongan</label>
        <select name="kode_gol" class="form-control">
        <?php $__currentLoopData = $gol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($g->kode_gol); ?>"><?php echo e($g->pangkat); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        </div>

        <div class="row">
        <div class="col-md-12">
        <label >Ket</label>
        <input type="text" name="ket" class="form-control">
        </div>
        </div>

<div class="row m-3">
<input type="submit" value="Tambah" class="btn btn-success">
</div>
        </form>
        <!-- end card -->
        </div>

  </div>
  <div class="tab-pane fade" id="nav-hapus2" role="tabpanel" aria-labelledby="nav-hapus-tab2">
  <?php if($pegawai->riwayatjabatan->count() !== 0): ?>
<!-- start hapus diklat -->
<?php $__currentLoopData = $pegawai->riwayatjabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/pegawai/jabatan/hapus/<?php echo e($rjbt->id_jabatan); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($rjbt->id_peg); ?>">
<button type="submit" class="btn btn-danger btn-sm m-2">Hapus riwayat dgn no. sk <?php echo e($rjbt->no_sk); ?></button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- end hapus diklat -->
<?php else: ?>
Belum ada data jabatan
<?php endif; ?>
  </div>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- end modal jabatan -->

<!-- start modal jabatan lain -->
<div class="modal fade" id="ModalJabatanfungsional" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Data Jabatan Fungsional</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active" id="nav-home-tab3" data-toggle="tab" href="#nav-home3" role="tab" aria-controls="nav-home3" aria-selected="true">Home</a>
    <a class="nav-item nav-link" id="nav-profile-tab3" data-toggle="tab" href="#nav-profile3" role="tab" aria-controls="nav-profile3" aria-selected="false">Tambah</a>
    <a class="nav-item nav-link" id="nav-hapus-tab3" data-toggle="tab" href="#nav-hapus3" role="tab" aria-controls="nav-hapus3" aria-selected="false">Hapus</a>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-home3" role="tabpanel" aria-labelledby="nav-home-tab3">
  <!-- start home jabatan lain -->
  <div class="card p-3">
  <?php if($pegawai->riwayatjabatanf->count() !== 0): ?>
  <div class="row">
  <div class="col-md-5">
  Nama
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rjbtf->jabatanfungsional->nama_jabatan); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-5">
  Level
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rjbtf->jabatanfungsional->level); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-5">
  Ket. Jabatan
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbtf->jabatanfungsional->ket); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-5">
  No. SK
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rjbtf->no_sk); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-5">
  Tanggal SK
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbtf->tgl_sk); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-5">
  Pejabat Pengesah
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbtf->pejabat_sk); ?></span>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-5">
  Terhitung Mulai
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"> <?php echo e($rjbtf->tmt); ?> </span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-5">
  Keterangan
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-primary"><?php echo e($rjbtf->ket); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div><hr>

  <div class="row">
  <div class="col-md-5">
  Aksi
  </div>
  <div class="col-md-7">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a class="btn btn-primary btn-sm" href="/pegawai/jabatanfungsional/editpage/<?php echo e($rjbtf->id_jabatanf); ?>/<?php echo e($pegawai->id_peg); ?>">Edit</a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
<?php else: ?>
Belum ada data
<?php endif; ?>
  <!-- card -->
  </div>
  <!-- end home jabtan lain -->
  </div>
  <div class="tab-pane fade" id="nav-profile3" role="tabpanel" aria-labelledby="nav-profile-tab3">
        <div class="card p-3">
        <!-- card -->
        <form action="/pegawai/jabatanfungsional/tambah" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">

        <div class="row">
        <div class="col-md-6">
        <label>No. SK</label>
        <input type="text" name="no_sk" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Tanggal SK</label>
        <input type="date" name="tgl_sk" class="form-control">
        </div>
        </div>

        <div class="row mt-2">
        <div class="col-md-6">
        <label>Pejabat Pengesah</label>
        <input type="text" name="pejabat_sk" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Jabatan Fungsional</label>
        <select name="kode_jbtf" class="form-control">
        <?php $__currentLoopData = $jbtf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($j->kode_jbtf); ?>"><?php echo e($j->nama_jabatan); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        </div>

        <div class="row mt-2">
        <div class="col-md-6">
        <label>Terhitung Mulai</label>
        <input type="date" name="tmt" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Golongan</label>
        <select name="kode_gol" class="form-control">
        <?php $__currentLoopData = $gol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($g->kode_gol); ?>"><?php echo e($g->pangkat); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        </div>
        
        <div class="row mt-2">
        <div class="col-md-12">
        <label>Keterangan</label>
        <input type="text" name="ket" class="form-control">
        </div>
        </div>

        <div class="row m-2">
        <input type="submit" value="Tambah" class="btn btn-success">
        </div>

        </form>
        <!-- end card -->
        </div>

  </div>
  <div class="tab-pane fade" id="nav-hapus3" role="tabpanel" aria-labelledby="nav-hapus-tab3">
  <?php if($pegawai->riwayatjabatanf->count() !== 0): ?>
<!-- start hapus diklat -->
<?php $__currentLoopData = $pegawai->riwayatjabatanf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/pegawai/jabatanfungsional/hapus/<?php echo e($rjbtf->id_jabatanf); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($rjbtf->id_peg); ?>">
<button type="submit" class="btn btn-danger btn-sm m-2">Hapus Jabatan dgn no. sk <?php echo e($rjbtf->no_sk); ?></button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- end hapus diklat -->
<?php else: ?>
Belum ada data jabatan
<?php endif; ?>
  </div>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- end modal jabatan lain -->

<!-- start modal jabatan lain -->
<div class="modal fade" id="ModalJabatanfungsionaltambahan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Data Jabatan Fungsional Tambahan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active" id="nav-home-tab31" data-toggle="tab" href="#nav-home31" role="tab" aria-controls="nav-home31" aria-selected="true">Home</a>
    <a class="nav-item nav-link" id="nav-profile-tab31" data-toggle="tab" href="#nav-profile31" role="tab" aria-controls="nav-profile31" aria-selected="false">Tambah</a>
    <a class="nav-item nav-link" id="nav-hapus-tab31" data-toggle="tab" href="#nav-hapus31" role="tab" aria-controls="nav-hapus31" aria-selected="false">Hapus</a>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-home31" role="tabpanel" aria-labelledby="nav-home-tab31">
  <!-- start home jabatan lain -->
  <div class="card p-3">
  <?php if($pegawai->riwayatjabatanft->count() !== 0): ?>

  <div class="row">
  <div class="col-md-4">
  Tugas Tambahan
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($rjbtft->jabatanfungsionalt->tugas_tambahan); ?> </span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><hr>

<div class="row">
  <div class="col-md-4">
  Jabatan
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($rjbtft->jabatanfungsionalt->jabatan); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><hr>

<div class="row">
  <div class="col-md-4">
  Level
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($rjbtft->jabatanfungsionalt->level); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><hr>

<div class="row">
  <div class="col-md-4">
  Ket. Tugas
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($rjbtft->jabatanfungsionalt->ket); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><hr>

<div class="row">
  <div class="col-md-4">
  No. SK
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($rjbtft->no_sk); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><hr>

<div class="row">
  <div class="col-md-4">
  Tanggal SK
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($rjbtft->tgl_sk); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><hr>

<div class="row">
  <div class="col-md-4">
  Pejabat Pengesah
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($rjbtft->pejabat_sk); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><hr>

<div class="row">
  <div class="col-md-4">
  Terhitung Mulai
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="badge badge-primary"><?php echo e($rjbtft->tmt); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><hr>

<div class="row">
  <div class="col-md-4">
  Aksi
  </div>
  <div class="col-md-8">
  : <?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a class="btn btn-primary btn-sm" href="/pegawai/jabatanfungsionalt/editpage/<?php echo e($rjbtft->id_jbtft); ?>/<?php echo e($pegawai->id_peg); ?>">Edit</a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>

<?php else: ?>
Belum ada data
<?php endif; ?>
  <!-- card -->
  </div>
  <!-- end home jabtan lain -->
  </div>
  <div class="tab-pane fade" id="nav-profile31" role="tabpanel" aria-labelledby="nav-profile-tab31">
  <div class="card p-3">
        <!-- card -->
        <form action="/pegawai/jabatanfungsionalt/tambah" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($pegawai->id_peg); ?>">

        <div class="row">
        <div class="col-md-6">
        <label>No. SK</label>
        <input type="text" name="no_sk" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Tanggal SK</label>
        <input type="date" name="tgl_sk" class="form-control">
        </div>
        </div>

        <div class="row mt-2">
        <div class="col-md-6">
        <label>Pejabat Pengesah</label>
        <input type="text" name="pejabat_sk" class="form-control">
        </div>
        <div class="col-md-6">
        <label>Jabatan Tambahan</label>
        <select name="kode_jbtft" class="form-control">
        <?php $__currentLoopData = $jbtft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($j->kode_jbtft); ?>"><?php echo e($j->tugas_tambahan); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        </div>

        <div class="row mt-2">
        <div class="col-md-12">
        <label>Terhitung Mulai</label>
        <input type="date" name="tmt" class="form-control">
        </div>
        </div>

        <div class="row m-2">
        <input type="submit" value="Tambah" class="btn btn-success">
        </div>

        </form>
        <!-- end card -->
        </div>
  </div>
  <div class="tab-pane fade" id="nav-hapus31" role="tabpanel" aria-labelledby="nav-hapus-tab31">
  <?php if($pegawai->riwayatjabatanft->count() !== 0): ?>
<!-- start hapus diklat -->
<?php $__currentLoopData = $pegawai->riwayatjabatanft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rjbtft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/pegawai/jabatanfungsionalt/hapus/<?php echo e($rjbtft->id_jbtft); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id_peg" value="<?php echo e($rjbtft->id_peg); ?>">
<button type="submit" class="btn btn-danger btn-sm m-2">Hapus data dgn no. sk <?php echo e($rjbtft->no_sk); ?></button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- end hapus diklat -->
<?php else: ?>
Belum ada data jabatan
<?php endif; ?>
  </div>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- end modal jabatan lain -->
          <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.induk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sistem-informasi-kepegawaian-master/resources/views/pegawai/profile.blade.php ENDPATH**/ ?>